import com.example.*;

import org.omg.CORBA.ORB;
import org.omg.CORBA.Object;
import org.omg.PortableServer.POA;
import org.omg.PortableServer.POAHelper;
import org.omg.PortableServer.POAManager;
import org.omg.CosNaming.NameComponent;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;

public class Main {

	public static void main (String[] args) {
	
	    try {	
		//Step 1 --- Create and initialize ORB
		//Will use ORB available in the classpath at run time 
		ORB orb = ORB.init(args,null);
		System.out.println("INFO ============> ORB is initialized property!!!");
		System.out.println(orb);

		//Step 2 --- Get Root Context from a connected Running Naming Service/Server 
		org.omg.CORBA.Object rootContextCorbaObject = orb.resolve_initial_references("NameService");
		NamingContextExt rootContext = NamingContextExtHelper.narrow(rootContextCorbaObject);		
		System.out.println("INFO ============> Connected to running Naming Service!!!");

		//Step 3 --- Lookup for server component by its string name from connected naming service
		org.omg.CORBA.Object holidayServiceCorbaObject = rootContext.resolve_str("holiday");
		System.out.printf("Lookedup Object Address Before Narrow : %s!!!%n", holidayServiceCorbaObject);
		HolidayService holidayService = HolidayServiceHelper.narrow(holidayServiceCorbaObject);				
		System.out.printf("Lookedup Object Address After Narrow : %s!!!%n", holidayService);
	
		String result = holidayService.playForVacation("Feb", "Manali");
		System.out.println(result);

		System.out.println("INFO ============> Finished!!!");
	   
           } catch(Exception ex){
		System.out.println("ERROR ============> Error in connecting to server!!!");
		ex.printStackTrace();			
           }	
			
	}

}

