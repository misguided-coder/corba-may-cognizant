package com.example;


/**
 * Generated from IDL interface "HolidayService".
 *
 * @author JacORB IDL compiler V 3.9
 * @version generated at 11 May, 2021 5:06:45 PM
 */

public abstract class HolidayServiceHelper
{
	private volatile static org.omg.CORBA.TypeCode _type;
	public static org.omg.CORBA.TypeCode type ()
	{
		if (_type == null)
		{
			synchronized(HolidayServiceHelper.class)
			{
				if (_type == null)
				{
					_type = org.omg.CORBA.ORB.init().create_interface_tc("IDL:com/example/HolidayService:1.0", "HolidayService");
				}
			}
		}
		return _type;
	}

	public static void insert (final org.omg.CORBA.Any any, final com.example.HolidayService s)
	{
			any.insert_Object(s);
	}
	public static com.example.HolidayService extract(final org.omg.CORBA.Any any)
	{
		return narrow(any.extract_Object()) ;
	}
	public static String id()
	{
		return "IDL:com/example/HolidayService:1.0";
	}
	public static HolidayService read(final org.omg.CORBA.portable.InputStream in)
	{
		return narrow(in.read_Object(com.example._HolidayServiceStub.class));
	}
	public static void write(final org.omg.CORBA.portable.OutputStream _out, final com.example.HolidayService s)
	{
		_out.write_Object(s);
	}
	public static com.example.HolidayService narrow(final org.omg.CORBA.Object obj)
	{
		if (obj == null)
		{
			return null;
		}
		else if (obj instanceof com.example.HolidayService)
		{
			return (com.example.HolidayService)obj;
		}
		else if (obj._is_a("IDL:com/example/HolidayService:1.0"))
		{
			com.example._HolidayServiceStub stub;
			stub = new com.example._HolidayServiceStub();
			stub._set_delegate(((org.omg.CORBA.portable.ObjectImpl)obj)._get_delegate());
			return stub;
		}
		else
		{
			throw new org.omg.CORBA.BAD_PARAM("Narrow failed");
		}
	}
	public static com.example.HolidayService unchecked_narrow(final org.omg.CORBA.Object obj)
	{
		if (obj == null)
		{
			return null;
		}
		else if (obj instanceof com.example.HolidayService)
		{
			return (com.example.HolidayService)obj;
		}
		else
		{
			com.example._HolidayServiceStub stub;
			stub = new com.example._HolidayServiceStub();
			stub._set_delegate(((org.omg.CORBA.portable.ObjectImpl)obj)._get_delegate());
			return stub;
		}
	}
}
