import com.example.*;

public class HolidayServiceImpl extends HolidayServicePOA {

	public String playForVacation (String month, String destination) {
		System.out.println("INFO ==================> Inside HolidayServiceImpl.playForVacation()");
		return "Lets plan for "+month+" months long holiday for "+destination;		
	}
}

