import com.example.*;

import org.omg.CORBA.ORB;
import org.omg.CORBA.Object;
import org.omg.PortableServer.POA;
import org.omg.PortableServer.POAHelper;
import org.omg.PortableServer.POAManager;
import org.omg.CosNaming.NameComponent;
import org.omg.CosNaming.NamingContext;
import org.omg.CosNaming.NamingContextHelper;

public class Main {

	public static void main (String[] args) {
	
	    try {	
		//Step 1 --- Create and initialize ORB
		//Will use ORB available in the classpath at run time 
		ORB orb = ORB.init(args,null);
		System.out.println("INFO ============> ORB is initialized property!!!");
		System.out.println(orb);

 		//Step 2 --- Get Reference to Root POA and activate it
		org.omg.CORBA.Object rootPOACorbaObject = orb.resolve_initial_references("RootPOA");
		POA rootPOA =  POAHelper.narrow(rootPOACorbaObject);
		POAManager poaManager = rootPOA.the_POAManager();
		poaManager.activate(); //Now POA is active and can entertain any admin calls or client calls
		System.out.println("INFO ============> ROOT POA is ready and active!!!");

		//Step 3 ---- Create servent object
		HolidayServiceImpl holidayServiceImpl = new HolidayServiceImpl();
		
		//Step 4 ---- Convert, Register and Obtain corba object reference for the servent object
		org.omg.CORBA.Object serventToCorbaObject = rootPOA.servant_to_reference(holidayServiceImpl);

		//Step 5 ---- Prepare corba object reference in a format so that it cab be bound to NamingService
		HolidayService holidayService = HolidayServiceHelper.narrow(serventToCorbaObject);					
		//Step 6 --- Get Root Context from a connected Running Naming Service/Server 
		org.omg.CORBA.Object rootContextCorbaObject = orb.resolve_initial_references("NameService");
		NamingContext rootContext = NamingContextHelper.narrow(rootContextCorbaObject);		
		System.out.println("INFO ============> Connected to running Naming Service!!!");

		//Step 7 --- Bind/Register obejcts to Naming Service/Server so that clients can lookup them
		NameComponent nameComponent = new NameComponent("holiday",""); 
		NameComponent[] nameComponents = new NameComponent[1];
		nameComponents[0] = nameComponent;
		//rootContext.bind(nameComponents,holidayService);
		rootContext.rebind(nameComponents,holidayService);
		System.out.println("INFO ============> Published Holiday server component!!!");
					
		//Step 8 --- Start ORB Broker so that broker can listen to incoming client method calls
		System.out.println("INFO ============> ORB Server is up and running and waiting for client calls!!!");
		orb.run();
           
           } catch(Exception ex){
		System.out.println("ERROR ============> Error in starting server!!!");
		ex.printStackTrace();			
           }	
			
	}

}

