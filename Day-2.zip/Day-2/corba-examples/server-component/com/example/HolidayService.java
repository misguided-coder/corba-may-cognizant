package com.example;

/**
 * Generated from IDL interface "HolidayService".
 *
 * @author JacORB IDL compiler V 3.9
 * @version generated at 11 May, 2021 4:57:52 PM
 */

public interface HolidayService
	extends HolidayServiceOperations, org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity
{
}
