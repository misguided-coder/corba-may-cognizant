package com.example;

/**
 * Generated from IDL interface "HolidayService".
 *
 * @author JacORB IDL compiler V 3.9
 * @version generated at 11 May, 2021 4:57:52 PM
 */

public final class HolidayServiceHolder	implements org.omg.CORBA.portable.Streamable{
	 public HolidayService value;
	public HolidayServiceHolder()
	{
	}
	public HolidayServiceHolder (final HolidayService initial)
	{
		value = initial;
	}
	public org.omg.CORBA.TypeCode _type()
	{
		return HolidayServiceHelper.type();
	}
	public void _read (final org.omg.CORBA.portable.InputStream in)
	{
		value = HolidayServiceHelper.read (in);
	}
	public void _write (final org.omg.CORBA.portable.OutputStream _out)
	{
		HolidayServiceHelper.write (_out,value);
	}
}
